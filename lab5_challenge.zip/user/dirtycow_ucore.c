#include <ulib.h>
#include <unistd.h>
#include <stdio.h>

static char pagebuf[4096];

// 最小 ecall 封装：a0=num, a1=arg1, a2=arg2，返回值在 a0
static inline long u_syscall2(long num, long arg1, long arg2) {
    register long a0 asm("a0") = num;
    register long a1 asm("a1") = arg1;
    register long a2 asm("a2") = arg2;
    asm volatile("ecall"
                 : "+r"(a0)
                 : "r"(a1), "r"(a2)
                 : "memory");
    return a0;
}

int main(void) {
    pagebuf[0] = 'A';

    int pid = fork();
    if (pid < 0) {
        cprintf("fork failed\n");
        return -1;
    }

    if (pid == 0) {
        // 子进程：不断写，触发 COW（正常路径）
        for (int i = 0; i < 500000; i++) {
            pagebuf[0] = 'B';
            if ((i & 1023) == 0) {
                yield(); // 增强交错，提高“竞态”概率
            }
        }
        exit(0);
    }

    // 父进程：通过漏洞 syscall 写共享页（绕过 COW）
    for (int i = 0; i < 500000; i++) {
        // SYS_kmemwrite(va, value)
        u_syscall2(SYS_kmemwrite, (long)&pagebuf[0], (long)'X');
        if ((i & 1023) == 0) {
            yield(); // 增强交错
        }
    }

    waitpid(pid, NULL);

    if (pagebuf[0] == 'X') {
        cprintf("DIRTY COW TRIGGERED: parent page corrupted!\n");
    } else {
        cprintf("COW SAFE: %c\n", pagebuf[0]);
    }

    return 0;
}
